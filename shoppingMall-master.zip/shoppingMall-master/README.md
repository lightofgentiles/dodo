# shoppingMall

Spring Boot Gradle을 이용한 쇼핑몰 프로젝트입니다.

간단한 게시판 CRUD구현과 회원가입,로그인 등 웹 개발의 기본에 충실한 프로젝트입니다.

환경셋팅 

Ecilpse 2019-09

java - jdk 1.8.0

Spring Boot Gradle

Mybatis

Thymeleaf 엔진

디자인 출처
http://www.nibbuns.co.kr/
